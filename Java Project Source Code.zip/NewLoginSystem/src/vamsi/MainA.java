package vamsi;

public class MainA {
	
	public static void main(String args[])
	{
		Main1 obj1 = new Main1();
	}

}
