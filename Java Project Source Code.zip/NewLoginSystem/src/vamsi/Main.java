package vamsi;

public class Main {
	
	public static void main(String args[])
	{
		Main1 obj1 = new Main1();
	}

}
